package com.example.back_end.service.impl;

import com.example.back_end.dto.PackageDTO;
import com.example.back_end.entity.ShootPackage;
import com.example.back_end.repo.PackageRepository;
import com.example.back_end.service.PackageService;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class PackageServiceImpl implements PackageService {
    @Autowired
    private PackageRepository packageRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public void savePackage(PackageDTO packageDTO) {
        packageRepository.save(modelMapper.map(packageDTO, ShootPackage.class));
    }

    @Override
    public List<PackageDTO> getAllPackages() {
        return modelMapper.map(packageRepository.findAll(),new TypeToken<List<PackageDTO>>() {}.getType());

    }

    @Override
    public void updatePackage(String id, PackageDTO packageDTO) {
        ShootPackage existingPackage = packageRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Package not found."));
        existingPackage.setName(packageDTO.getName());
        existingPackage.setDescription(packageDTO.getDescription());
        existingPackage.setPrice(packageDTO.getPrice());
        existingPackage.setDuration(packageDTO.getDuration());
        packageRepository.save(existingPackage);
    }

    @Override
    public void deletePackage(String id) {
        packageRepository.deleteById(id);
    }

    @Override
    public PackageDTO getPackageByName(String name) {
        ShootPackage packaage = packageRepository.findByName(name);
        return modelMapper.map(packaage, PackageDTO.class);
    }
}
