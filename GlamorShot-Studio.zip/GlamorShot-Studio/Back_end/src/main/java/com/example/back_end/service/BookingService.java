package com.example.back_end.service;

import com.example.back_end.dto.BookingDTO;
import com.example.back_end.entity.Booking;

import java.util.List;

public interface BookingService {
    void save(BookingDTO bookingDTO);
    void save(Booking booking);
    void delete(Long id);
    void update(Long id, BookingDTO bookingDTO);
    List<BookingDTO> getAllBookings();
    List<BookingDTO> getByUserId(Long userId);
}
