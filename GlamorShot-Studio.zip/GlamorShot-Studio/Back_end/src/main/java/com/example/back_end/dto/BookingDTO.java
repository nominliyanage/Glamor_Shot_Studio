package com.example.back_end.dto;

import com.example.back_end.entity.Booking;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BookingDTO {
    private Long id;
    private PackageDTO shootPackage;
    private String packageName;
    private UserDTO user;
    private String userEmail;
    private LocalDate shootDate;
    private int numberOfGuests;
    private String additionalRequests;
    private Booking.BookingStatus status;
}
