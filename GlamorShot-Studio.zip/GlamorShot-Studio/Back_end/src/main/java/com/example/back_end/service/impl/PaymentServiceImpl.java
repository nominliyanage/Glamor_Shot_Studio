package com.example.back_end.service.impl;

import com.example.back_end.dto.PaymentDTO;
import com.example.back_end.entity.Booking;
import com.example.back_end.entity.Payment;
import com.example.back_end.repo.BookingRepository;
import com.example.back_end.repo.PaymentRepository;
import com.example.back_end.service.PaymentService;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Value("${payhere.merchant.secret}")
    private static String merchantSecret;


    @Override
    public boolean save(PaymentDTO paymentDTO) {
        try {
            Payment payment = modelMapper.map(paymentDTO, Payment.class);
            paymentRepository.save(payment);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public void delete(Long id) {
        paymentRepository.deleteById(id);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public void update(Long id, PaymentDTO paymentDTO) {
        Payment existingPayment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));

        existingPayment.setAmount(paymentDTO.getAmount());

        try {
            existingPayment.setMethod(Payment.PaymentMethod.valueOf(paymentDTO.getMethod()));
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid payment method: " + paymentDTO.getMethod());
        }

        Booking booking = bookingRepository.findById(paymentDTO.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found with id: " + paymentDTO.getBookingId()));

        existingPayment.setBooking(booking);
        existingPayment.setPaymentDate(paymentDTO.getPaymentDate());

        paymentRepository.save(existingPayment);
    }


    @Override
    public List<PaymentDTO> getAll() {
        return modelMapper.map(paymentRepository.findAll(),new TypeToken<List<PaymentDTO>>() {}.getType());
    }
//    public List<Payment> getPaymentsByHotelId(Long hotelId) {
//        returnn paymentRepository.findPaymentsByHotelId(hotelId);
//    }
}
