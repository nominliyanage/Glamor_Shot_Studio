package com.example.back_end.service;

import com.example.back_end.dto.PaymentDTO;

import java.util.List;

public interface PaymentService {
    boolean save(PaymentDTO paymentDTO);

    void delete(Long id);

    void update(Long id, PaymentDTO paymentDTO);

    List<PaymentDTO> getAll();
}
