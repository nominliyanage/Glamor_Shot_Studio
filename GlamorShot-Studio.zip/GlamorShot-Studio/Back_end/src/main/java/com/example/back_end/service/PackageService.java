package com.example.back_end.service;

import com.example.back_end.dto.PackageDTO;

import java.util.List;

public interface PackageService {
    void savePackage(PackageDTO packageDTO);
    List<PackageDTO> getAllPackages();
    void updatePackage(String id, PackageDTO packageDTO);
    void deletePackage(String id);
    PackageDTO getPackageByName(String name);
}
